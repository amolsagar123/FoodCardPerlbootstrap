var base64 = [
'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/' ];
// ***** SWITCH BASE64 CODE ***** 
function switchBase64 () {
	var zz = new Object();
	for (var i = 0; i < 64; i++) {
		zz[base64[i]] = i;
	}
	return zz;
}
var switchedBase64 = switchBase64();
// ***** STRIP OUT CR AND LF *****
function stripCRLF(myStr){
	var rLine = /\r/g;
	myStr = myStr.replace(rLine, '');
	var nLine = /\n/g;
	myStr = myStr.replace(nLine, '');
	decode(myStr);
}
// ***** DECODE THE TEXTAREA *****
function decode (B64Str) {
	var charIs = new Array();
	var NewStr = "";
	for (var i = 0; i < B64Str.length; i++){
		charIs[i] = switchedBase64[B64Str.charAt(i)];
	}
	for (var i = 0; i < B64Str.length; i += 4) {
		var b24  = (charIs [i] & 0xFF) << 18; 
		b24 |= (charIs[i + 1] & 0xFF) << 12; 
		b24 |= (charIs[i + 2] & 0xFF) << 6;
		b24 |= (charIs[i + 3] & 0xFF) << 0;
		NewStr += String.fromCharCode((b24 & 0xFF0000) >> 16);
		if (B64Str.charAt(i + 2) != '='){
			NewStr += String.fromCharCode((b24 & 0xFF00) >> 8);
		}
		if (B64Str.charAt(i + 3) != '='){
			NewStr += String.fromCharCode((b24 & 0xFF) >> 0);
		}
	}
	return NewStr;
}
