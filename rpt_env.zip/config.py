import os

RETURN_MAIL_PATH = "D:\PythonApp\suburban_data_processing\ARCHIVE\RETURN_MAIL"
NCOA_PATH = "D:\PythonApp\suburban_data_processing\ARCHIVE\\NCOA"
CONSOL_RPT_PATH = "D:\PythonApp\suburban_data_processing\ARCHIVE\CONSOL_RPTS"
FTP_SERVER = "ftp0.contentcritical.com"
SFTP_SERVER = "sftp.contentcritical.com"
SFTP_USERNAME = "sbp22"
SFTP_PASSWORD = "UwYRazQ2X1cyM1z!"