"""

Author: Amol S. 
Version: 1.0

"""

from datetime import datetime
import os
import shutil
from config import INPUT_PATH, Q1INPUT_COLUMNS
import pandas as pd 
import glob
#pip install jinja2
#pip install openpyxl



def get_input_filenames(path):
     
    """
      Get the source file(s)
    """ 
    filepattern = "*E3_241216_SAESTA_CUSTRPT.csv"    
    input_filenames = glob.glob(os.path.join(path,filepattern))    
    return input_filenames

 

def display_message(message, lck_filename="process.lck"):
    """Updates a log file with a message. Also adds to log file time that message was added.

    Args:
        message (str): Message being logged.
    """
    with open(lck_filename, "a+") as lock_file:
        print(message)
        lock_file.write(datetime.now().strftime("%Y:%m:%d - %H:%M:%S -- ") + message + "\n")
        
def C_column_cellcolor(result): 
    color = '#FF0000' if result == "FAIL" else "#009900"
    return f'background-color:{color}'
        
def procecc_file(file):       
    df =   pd.read_csv(file)
    df =   df.fillna('')                   
    C_columns = []
    for index, column in enumerate(df.columns):                    
        if column in Q1INPUT_COLUMNS:                          
            colindex = int(df.columns.get_loc(column)) + 1
            C_column = 'C'+ str(index + 1)
            C_columns.append(C_column)
            df.insert(colindex,C_column,'')                
            for rowindex,value in enumerate(df[column].fillna('')):                                       
               if len(str(value).strip()) > 0: 
                   df.loc[rowindex,C_column] = "PASS"                   
               else: 
                   df.loc[rowindex,C_column] = "FAIL"              
    styled_df = df.style.applymap(C_column_cellcolor, subset=C_columns)            
    return styled_df   
     
                

def main():    
    input_filenames = get_input_filenames(INPUT_PATH) 
    print(input_filenames)   
    for file in  input_filenames: 
        display_message(f"    Processing File  {os.path.basename(file)}.")   
        df = procecc_file(file) 
        display_message(f"    Converting To Excel.")  
        excelfile = os.path.join(INPUT_PATH,file[:-4]+".xlsx")
        df.to_excel(excelfile, index=False)   
        
    
if __name__ == "__main__":
    # if os.path.exists("process.lck"):
    #     sys.exit()
    log_filename = os.path.join("LOGS", datetime.now().strftime("%Y%m%d%H%M%S") + ".log")    
    with open("process.lck", "a+") as lock_file:
        lock_file.write("Process Running\n") 
    try:
        main()
    except Exception as error:        
        pass
    shutil.move("process.lck", log_filename)