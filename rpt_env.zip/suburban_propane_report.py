"""
Suburbun Propane Consolidated reports for Returnmail, NCOA etc.

Author: Amol S. 
Version: 1.0

"""

from datetime import datetime
from ftplib import FTP
import json
import os
from pprint import pprint
import re
import shutil
import sys
import time
from zipfile import ZipFile
from config import RETURN_MAIL_PATH, NCOA_PATH,CONSOL_RPT_PATH,SFTP_SERVER, SFTP_USERNAME, SFTP_PASSWORD
from dependencies.utility_functions import send_email, send_error_email,sftp_upload
import pandas as pd 
import glob
import random
import numpy as np
from numpy import loadtxt
import re
import operator
import os.path

rundate = datetime.now().strftime("%Y%m%d")
rundate = rundate[2:]
#rundate= '240326'
print(rundate)
    
CONSOL_REPORTNAME = "SUBURBAN_RETURNMAIL_" + rundate + "_CONS_CUSTRPT.csv"
consol_report = os.path.join(CONSOL_RPT_PATH,CONSOL_REPORTNAME) 
CONSOL_NCOA_RPT = "SUBURBAN_" + rundate + "_ncoa.001"
colsol_ncoa_rpt = os.path.join(CONSOL_RPT_PATH,CONSOL_NCOA_RPT) 
colsol_ncoa_cons_rpt = os.path.join(CONSOL_RPT_PATH,"SUBURBAN_" + rundate + "_CONS_ncoa.001")
#colsol_ncoa_cons_rpt = os.path.join(CONSOL_RPT_PATH,"SUBURBAN_ONETIME_CONS_ncoa.001")

# CONNECT_STRING = "DRIVER={PostgreSQL Unicode};Trusted_connection=no;SERVER=localhost;PORT=5432; DATABASE=suburban_sandbox;UID=processing;PWD=processing07072"
# regexp = re.compile("DATABASE=(.*)$")
# database = regexp.search(CONNECT_STRING).group(1).split(';')
# print(database[0])
# sys.exit(0)

def get_input_filenames(path,rundate):
    
    filepattern = "*" + rundate + "*" 
    # dates = ['*240506_SAE*','*240507*']
    # files_grabbed = []   
    # for files in dates: 
    #     input_filenames = glob.glob(os.path.join(path,files))   
    #     files_grabbed.extend(input_filenames)                                                                                                                   
    # return files_grabbed
    input_filenames = glob.glob(os.path.join(path,filepattern))    
    return input_filenames


class NoDatException(Exception):
    pass

def main():
     
    try:     
       """
       Suburban Propane Consolidated report for Returnmail 
       """ 
    
       print(rundate)
       input_filenames = get_input_filenames(RETURN_MAIL_PATH,rundate) 
       print(input_filenames)   
       
       df = (pd.concat(pd.read_csv(v, on_bad_lines='skip')
                 for v in input_filenames)        
       )
       #df = pd.concat(map(pd.read_csv, input_filenames), ignore_index=True)       
           
       df1 = df.drop_duplicates().sort_values(by=['CSC','Acct Number'])      
       df1["NEW5DigitZIPCode"]= df1["NEW5DigitZIPCode"].str.replace(r"-", "")
       df1.to_csv(consol_report, encoding='utf-8', index=False, mode='w') 
       df.drop(df.index, inplace=True)
       df1.drop(df1.index, inplace=True)
       sftp_upload(consol_report, SFTP_SERVER, SFTP_USERNAME, SFTP_PASSWORD, "/incoming/sub_returnedfile")
       send_email(
       "SUBURBAN RETURN MAIL FILE CONSOLIDATED",
       os.path.basename(consol_report),
       "help_desk@contentcritical.com",
       [
         "amol.sagar@contentcritical.com",
           "stephen.giardina@contentcritical.com",
            "tariq.mohamed@contentcritical.com",
            "riddhi.rana@contentcritical.com",
            "helene.fischer@contentcritical.com",
            "douglas.sikora@contentcritical.com",
            "spessoa@suburbanpropane.com", 
            "plucien@suburbanpropane.com",
            "cust_suburban@contentcritical.com",
            
        ],
        attachment=consol_report            
       
       )
       
       df1 = pd.DataFrame(None) 
              
       """
       Suburban Propane Consolidated report for Returnmail
       """            
       #rundate = rundate[2:]
       print(rundate)
       input_filenames = get_input_filenames(NCOA_PATH,rundate) 
       print(input_filenames)     
       if os.path.exists(colsol_ncoa_rpt):
            os.remove(colsol_ncoa_rpt)  
       with open(colsol_ncoa_rpt, 'w') as outfile:
         for fname in input_filenames:
           with open(fname) as infile:
               for line in infile:
                outfile.write(line)
       
        #  if os.path.exists(colsol_ncoa_rpt): 
        #     send_email(
        #    "NO RECORDS FOR {} SUBURBAN NCOA CONSOLIDATED".format(rundate),
        #    "",
        #    "help_desk@contentcritical.com",
        #    [
        #     "stephen.giardina@contentcritical.com",
        #     "tariq.mohamed@contentcritical.com",
        #     "riddhi.rana@contentcritical.com",
        #     "helene.fischer@contentcritical.com",
        #     "douglas.sikora@contentcritical.com",
        #     "spessoa@suburbanpropane.com", 
        #     "plucien@suburbanpropane.com",
        #     "cust_suburban@contentcritical.com",
        #     "amol.sagar@contentcritical.com",            
        #   ]           
       
        #   )
        #     raise NoDatException()   
                          
       df =  pd.read_csv(colsol_ncoa_rpt,sep="|",header=None )          
       print(df)
       df.columns = ["col1", "col2","col3", "col4","col5", "col6","col7", "col8","col9", "col10", "col11","col12", "col13","col14"]
       print(df)
       df = df.sort_values(by=['col1','col2'])
       print(df) 
   
       df["col11"]= df["col11"].str.replace(r"-", "")            
       df["col1"]= df["col1"].astype(str).str.replace(r"^",'"', regex=True)
       df["col1"]= df["col1"].astype(str).str.replace(r"$",'"', regex=True)
       df1 = df.drop_duplicates(["col1", "col2","col3", "col4","col5", "col6","col7", "col8","col9", "col10", "col11","col12", "col13","col14"])
       print(df1) 
    #    print(df)
    
       my_numpy1 = df1.to_numpy() 
       if os.path.exists(colsol_ncoa_cons_rpt):
            os.remove(colsol_ncoa_cons_rpt) 
       with open(colsol_ncoa_cons_rpt, "ab") as f:
           np.savetxt(f,my_numpy1,fmt='%s', delimiter='|',newline='\r\n')
       f.close()       
              
       sftp_upload(colsol_ncoa_cons_rpt, SFTP_SERVER, SFTP_USERNAME, SFTP_PASSWORD, "/incoming/sub_returnedfile")
       send_email(
        "SUBURBAN NCOA CONSOLIDATED",
        os.path.basename(colsol_ncoa_cons_rpt),
        "help_desk@contentcritical.com",
        [
            
            "tariq.mohamed@contentcritical.com",
            "riddhi.rana@contentcritical.com",
            "helene.fischer@contentcritical.com",
            "douglas.sikora@contentcritical.com",
            "spessoa@suburbanpropane.com", 
            "plucien@suburbanpropane.com",
            "cust_suburban@contentcritical.com",
            "amol.sagar@contentcritical.com",
            
        ],
        attachment=colsol_ncoa_cons_rpt            
       
      )
       
    except NoDatException: 
        pass    
    else:
        send_error_email(Exception)
        
    
if __name__ == "__main__":
    if os.path.exists("process.lck"):
        sys.exit()
    log_filename = os.path.join("LOGS", datetime.now().strftime("%Y%m%d%H%M%S") + ".log")
    #if os.path.exists(consol_report): 
       #shutil.move(consol_report, log_filename)
       #shutil.move(colsol_ncoa_rpt, log_filename)
    with open("process.lck", "a+") as lock_file:
        lock_file.write("Process Running\n") 
    try:
        main()
    except Exception as error:
        #send_error_email(error)
        pass
    shutil.move("process.lck", log_filename)